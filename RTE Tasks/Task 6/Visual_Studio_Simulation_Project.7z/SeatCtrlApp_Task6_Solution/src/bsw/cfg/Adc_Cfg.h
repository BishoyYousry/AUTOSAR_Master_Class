/**
 *
 * \brief Sprints AUTOSAR Master Class - SeatCtrlApp
 * \author Hassan Farahat
 *
 * For any inquiries: hassan.m.farahat@gmail.com
 *
 */
 
#ifndef ADC_CFG_H
#define ADC_CFG_H

#define AdcConf_AdcGroup_PositionsSensorsGrp			0U
#define ADC_GR0_NUM_CHANNELS							3U

#endif