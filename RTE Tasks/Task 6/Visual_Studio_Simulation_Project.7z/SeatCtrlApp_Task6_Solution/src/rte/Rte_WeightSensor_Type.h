/**
 *
 * \brief Sprints AUTOSAR Master Class - SeatCtrlApp
 * \author Hassan Farahat
 *
 * For any inquiries: hassan.m.farahat@gmail.com
 *
 */
 
#ifndef RTE_WEIGHTSENSOR_TYPE_H
#define RTE_WEIGHTSENSOR_TYPE_H

#include "Rte_Type.h"

#endif