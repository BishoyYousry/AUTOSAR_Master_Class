/**
 *
 * \brief Sprints AUTOSAR Master Class - SeatCtrlApp
 * \author Hassan Farahat
 *
 * For any inquiries: hassan.m.farahat@gmail.com
 *
 */
 
#ifndef RTE_IOHWABS_TYPE_H
#define RTE_IOHWABS_TYPE_H

#include "Rte_Type.h"

#endif